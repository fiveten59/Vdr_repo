#!/bin/bash

sudo /etc/init.d/vdr stop & /usr/bin/kodi
