

#include "graphtft.hpp"

//***************************************************************************
// Main
//***************************************************************************

int main(int argc, char *argv[])
{
    GraphTft graphTft;

    graphTft.setArgs(argc, argv);

    graphTft.start();

    return 0;
}

