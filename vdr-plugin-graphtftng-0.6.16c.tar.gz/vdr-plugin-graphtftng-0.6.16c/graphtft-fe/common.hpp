//***************************************************************************
// Group VDR/GraphTFT
// File common.hpp
// Date 04.11.06 - J�rg Wendel
// This code is distributed under the terms and conditions of the
// GNU GENERAL PUBLIC LICENSE. See the file COPYING for details.
//***************************************************************************

#ifndef __COMMON_HPP__
#define __COMMON_HPP__

int tell(int eloquence, const char* format, ...);

#endif // __COMMON_HPP__
